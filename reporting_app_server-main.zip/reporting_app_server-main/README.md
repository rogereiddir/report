Reporting App Server


Requirements :
Install Redis : yum install redis -y
install Nodejs : curl -sL https://rpm.nodesource.com/setup_14.x | sudo bash - ; sudo yum install nodejs -y
install postgres
install chrome
install git : yum install git -y


